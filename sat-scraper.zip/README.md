# SAT Scraper (Playwright)

Microservicio para descargar **Constancia de Situación Fiscal (CSF)** y **Opinión de Cumplimiento 32-D** del portal SAT usando e.Firma.

## Endpoints

- `GET  /health` → `{ ok: true }`
- `POST /constancia` → body: `{ rfc, cer_base64, key_base64, password }` → `{ ok, pdf_base64, regimen, ... }`
- `POST /opinion`    → body: `{ rfc, cer_base64, key_base64, password }` → `{ ok, pdf_base64, resultado, positiva }`

Auth: header `X-Api-Key: <SCRAPER_API_KEY>` (definida como variable en Railway).

## Despliegue en Railway

1. Sube este repo a GitHub.
2. En Railway: **New → Deploy from GitHub repo** → selecciona `sat-scraper`.
3. **Settings → Variables**: añade `SCRAPER_API_KEY` (cualquier string aleatorio).
4. **Settings → Networking → Generate Domain** (puerto `8080`).
5. **Settings → Regions**: solo `us-west2` (NO uses `sfo`).

Pasa la URL pública (`https://xxx.up.railway.app`) y `SCRAPER_API_KEY` a Lovable.
